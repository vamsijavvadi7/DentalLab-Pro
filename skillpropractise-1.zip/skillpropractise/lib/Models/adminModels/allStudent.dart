// To parse this JSON data, do
//
//     final allStudent = allStudentFromJson(jsonString);

import 'dart:convert';

List<AllStudent> allStudentFromJson(String str) =>
    List<AllStudent>.from(json.decode(str).map((x) => AllStudent.fromJson(x)));

String allStudentToJson(List<AllStudent> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class AllStudent {
  AllStudent({
    required this.personid,
    required this.firstName,
    required this.lastName,
    required this.password,
    required this.phone,
    required this.email,
    required this.studentId,
  });

  int personid;
  String firstName;
  String lastName;
  String password;
  String phone;
  String email;
  String studentId;

  factory AllStudent.fromJson(Map<String, dynamic> json) => AllStudent(
        personid: json["personid"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        password: json["password"],
        phone: json["phone"],
        email: json["email"],
        studentId: json["student_id"],
      );

  Map<String, dynamic> toJson() => {
        "personid": personid,
        "first_name": firstName,
        "last_name": lastName,
        "password": password,
        "phone": phone,
        "email": email,
        "student_id": studentId,
      };
}
