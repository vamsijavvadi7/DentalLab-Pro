// To parse this JSON data, do
//
//     final allAdmins = allAdminsFromJson(jsonString);

import 'dart:convert';

AllAdmins allAdminsFromJson(String str) => AllAdmins.fromJson(json.decode(str));

String allAdminsToJson(AllAdmins data) => json.encode(data.toJson());

class AllAdmins {
  AllAdmins({
    required this.adminname,
    required this.adminmail,
    required this.adminsdetails,
  });

  String adminname;
  String adminmail;
  List<Adminsdetail> adminsdetails;

  factory AllAdmins.fromJson(Map<String, dynamic> json) => AllAdmins(
        adminname: json["adminname"],
        adminmail: json["adminmail"],
        adminsdetails: List<Adminsdetail>.from(
            json["adminsdetails"].map((x) => Adminsdetail.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "adminname": adminname,
        "adminmail": adminmail,
        "adminsdetails":
            List<dynamic>.from(adminsdetails.map((x) => x.toJson())),
      };
}

class Adminsdetail {
  Adminsdetail({
    required this.personId,
    required this.firstName,
    required this.lastName,
    required this.password,
    required this.phone,
    required this.email,
  });

  int personId;
  String firstName;
  String lastName;
  String password;
  String phone;
  String email;

  factory Adminsdetail.fromJson(Map<String, dynamic> json) => Adminsdetail(
        personId: json["person_id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        password: json["password"],
        phone: json["Phone"],
        email: json["Email"],
      );

  Map<String, dynamic> toJson() => {
        "person_id": personId,
        "first_name": firstName,
        "last_name": lastName,
        "password": password,
        "Phone": phone,
        "Email": email,
      };
}
