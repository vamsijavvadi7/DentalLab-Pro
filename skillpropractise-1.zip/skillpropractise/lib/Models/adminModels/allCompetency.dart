// To parse this JSON data, do
//
//     final allCompetency = allCompetencyFromJson(jsonString);

import 'dart:convert';

AllCompetency allCompetencyFromJson(String str) =>
    AllCompetency.fromJson(json.decode(str));

String allCompetencyToJson(AllCompetency data) => json.encode(data.toJson());

class AllCompetency {
  AllCompetency({
    required this.details,
  });

  List<Detail> details;

  factory AllCompetency.fromJson(Map<String, dynamic> json) => AllCompetency(
        details:
            List<Detail>.from(json["details"].map((x) => Detail.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "details": List<dynamic>.from(details.map((x) => x.toJson())),
      };
}

class Detail {
  Detail({
    required this.competencyname,
    required this.competencyid,
  });

  String competencyname;
  int competencyid;

  factory Detail.fromJson(Map<String, dynamic> json) => Detail(
        competencyname: json["competencyname"],
        competencyid: json["competencyid"],
      );

  Map<String, dynamic> toJson() => {
        "competencyname": competencyname,
        "competencyid": competencyid,
      };
}
