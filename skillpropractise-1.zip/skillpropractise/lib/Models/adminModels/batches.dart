// To parse this JSON data, do
//
//     final batches = batchesFromJson(jsonString);

import 'dart:convert';

List<Batches> batchesFromJson(String str) =>
    List<Batches>.from(json.decode(str).map((x) => Batches.fromJson(x)));

String batchesToJson(List<Batches> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Batches {
  Batches({
    required this.batchName,
    required this.batchId,
  });

  String batchName;
  int batchId;

  factory Batches.fromJson(Map<String, dynamic> json) => Batches(
        batchName: json["batch_name"],
        batchId: json["batch_id"],
      );

  Map<String, dynamic> toJson() => {
        "batch_name": batchName,
        "batch_id": batchId,
      };
}
