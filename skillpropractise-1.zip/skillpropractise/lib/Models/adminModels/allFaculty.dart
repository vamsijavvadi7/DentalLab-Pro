// To parse this JSON data, do
//
//     final allFaculty = allFacultyFromJson(jsonString);

import 'dart:convert';

List<AllFaculty> allFacultyFromJson(String str) =>
    List<AllFaculty>.from(json.decode(str).map((x) => AllFaculty.fromJson(x)));

String allFacultyToJson(List<AllFaculty> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class AllFaculty {
  AllFaculty({
    required this.personid,
    required this.firstname,
    required this.lastname,
    required this.password,
    required this.phone,
    required this.email,
    required this.facultyid,
    required this.speciality,
  });

  int personid;
  String firstname;
  String lastname;
  String password;
  String phone;
  String email;
  String facultyid;
  String speciality;

  factory AllFaculty.fromJson(Map<String, dynamic> json) => AllFaculty(
        personid: json["personid"],
        firstname: json["firstname"],
        lastname: json["lastname"],
        password: json["password"],
        phone: json["phone"],
        email: json["email"],
        facultyid: json["facultyid"],
        speciality: json["speciality"],
      );

  Map<String, dynamic> toJson() => {
        "personid": personid,
        "firstname": firstname,
        "lastname": lastname,
        "password": password,
        "phone": phone,
        "email": email,
        "facultyid": facultyid,
        "speciality": speciality,
      };
}
