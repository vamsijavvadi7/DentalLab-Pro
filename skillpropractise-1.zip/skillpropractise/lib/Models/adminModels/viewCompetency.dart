// To parse this JSON data, do
//
//     final viewCompetency = viewCompetencyFromJson(jsonString);

import 'dart:convert';

ViewCompetency viewCompetencyFromJson(String str) =>
    ViewCompetency.fromJson(json.decode(str));

String viewCompetencyToJson(ViewCompetency data) => json.encode(data.toJson());

class ViewCompetency {
  ViewCompetency({
    required this.competencyname,
    required this.competencyid,
    required this.criteriadetails,
  });

  String competencyname;
  int competencyid;
  List<Criteriadetail> criteriadetails;

  factory ViewCompetency.fromJson(Map<String, dynamic> json) => ViewCompetency(
        competencyname: json["competencyname"],
        competencyid: json["competencyid"],
        criteriadetails: List<Criteriadetail>.from(
            json["criteriadetails"].map((x) => Criteriadetail.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "competencyname": competencyname,
        "competencyid": competencyid,
        "criteriadetails":
            List<dynamic>.from(criteriadetails.map((x) => x.toJson())),
      };
}

class Criteriadetail {
  Criteriadetail({
    required this.criteriaid,
    required this.criteriaqs,
    required this.option0,
    required this.option1,
    required this.option2,
  });

  int criteriaid;
  String criteriaqs;
  String option0;
  String option1;
  String option2;

  factory Criteriadetail.fromJson(Map<String, dynamic> json) => Criteriadetail(
        criteriaid: json["criteriaid"],
        criteriaqs: json["criteriaqs"],
        option0: json["option0"],
        option1: json["option1"],
        option2: json["option2"],
      );

  Map<String, dynamic> toJson() => {
        "criteriaid": criteriaid,
        "criteriaqs": criteriaqs,
        "option0": option0,
        "option1": option1,
        "option2": option2,
      };
}
