import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:firstskillpro/Models/adminModels/allAdmins.dart';
import 'package:firstskillpro/Models/adminModels/allCompetency.dart';
import 'package:firstskillpro/Models/adminModels/allFaculty.dart';
import 'package:firstskillpro/Models/adminModels/allSpeciality.dart';
import 'package:firstskillpro/Models/adminModels/allStudent.dart';
import 'package:firstskillpro/Models/adminModels/batches.dart';
import 'package:firstskillpro/Models/adminModels/viewCompetency.dart';
import 'package:flutter/material.dart';
import 'package:firstskillpro/Models/competencyDetails.dart';
import 'package:firstskillpro/Models/competencyList.dart';
import 'package:firstskillpro/Models/evaluationForm.dart';
import 'package:firstskillpro/Models/loginCheck.dart';
import 'package:firstskillpro/Models/one2oneStudentList.dart';
import 'package:firstskillpro/Models/profile.dart';
import 'package:firstskillpro/Models/referenceNeededList.dart';
import 'package:firstskillpro/Models/seeEvaluationForm.dart';
import 'package:firstskillpro/Models/specialityCheck.dart';
import 'package:firstskillpro/Models/specialityList.dart';
import 'package:firstskillpro/Models/studentEvaluation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Api extends ChangeNotifier {
  String globalPassword = "";
  String globalEmail = "";
  LoginCheck? loginCheck;
  CompetencyList? competencyList;
  List<CompetencyDetails> competencyDetailsList = [];
  List<StudentcompetencyList> studentcompetencyList = [];
  List<Profile> profileData = [];
  EvaluationForm? evaluationForm;
  List<StudentEvaluation> studentEvaluation = [];
  SeeEvaluationForm? seeEvaluationForm;
  SeeStudentEvaluation? seeStudentEvaluation;
  SpecialityCheck? specialityCheck;
  List<One2OneMeet> one2oneList = [];
  List<One2OneMeetStudent> one2oneStudentList = [];
  List<ReferenceNeeded> referenceList = [];
  List<ReferenceStudentList> referenceStudentList = [];
  SpecialitiesList? specialitiesList;

  String specialityForEvaluation = "";

  void notify() {
    notifyListeners();
  }

//------------------------ Local Storage ---------------------

  Future<bool> changeLoginStatus(String email, String password) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool m = await prefs.setString("email", email);
    m = await prefs.setString("password", password);
    globalEmail = email;
    globalPassword = password;
    notifyListeners();
    return true;
  }

  Future<bool> removeLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool m = await prefs.remove("email");
    m = await prefs.remove("password");
    globalPassword = "";
    globalEmail = "";
    competencyDetailsList = [];
    studentcompetencyList = [];
    profileData = [];
    studentEvaluation = [];
    one2oneList = [];
    one2oneStudentList = [];
    referenceList = [];
    referenceStudentList = [];
    allfaculty = [];
    allstudent = [];
    allBatches = [];
    notifyListeners();
    return true;
  }

// returns true if already logged In else false.
  Future<bool> getLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    // ignore: await_only_futures
    bool e = await prefs.containsKey('email');
    // ignore: await_only_futures
    bool p = await prefs.containsKey('password');
    if (e && p) {
      globalEmail = prefs.getString("email")!;
      globalPassword = prefs.getString("password")!;
      notifyListeners();
      return true;
    } else {
      return false;
    }
  }

//------------------------ For DashBoard ---------------------

  Future<bool> getCompetencyList({required String speciality}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/fdashboard/competencydetails/$speciality',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        competencyList = CompetencyList.fromJson(response.data);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in login check");
      return false;
    }
  }

  Future<bool> getSpecialityList() async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/studentdashboard/specialities',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        specialitiesList = SpecialitiesList.fromJson(response.data);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in login check");
      return false;
    }
  }

  Future<bool> getCompetencyDetailsList(
      {required String speciality, required int competencyid}) async {
    try {
      specialityForEvaluation = speciality;
      notifyListeners();
      Response response = await Dio().get(
        'https://api421.herokuapp.com/fdashboard/competencydetails/speciality/$speciality/competencyid/$competencyid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        competencyDetailsList =
            competencyDetailsFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in competenct list");
      print(e);
      return false;
    }
  }

  Future<bool> getStudentcompetencyList(
      {required String speciality, required String mail}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/studentdashboard/email/$mail/speciality/$speciality',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        studentcompetencyList =
            studentcompetencyListFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in login check");
      return false;
    }
  }

//------------------------ Profile Details & Login ---------------------

// checks for user and sends role
  Future<bool> loginStatusCheck(
      {required String mail, required String password}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/login/$mail/$password',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      print(response);
      if (response.statusCode == 200) {
        loginCheck = LoginCheck.fromJson(response.data);
        bool m = await changeLoginStatus(mail, password);
        notifyListeners();
        return m;
      }
      return false;
    } catch (e) {
      print(e);
      print("error in login check");
      return false;
    }
  }

  Future<bool> specialityStatusCheck({required String mail}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/fdashboard/details/$mail',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      print(response.data);
      if (response.statusCode == 200) {
        specialityCheck = SpecialityCheck.fromJson(response.data);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in speciality check");
      return false;
    }
  }

  Future<bool> getProfile({required String email}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/profile/email/$email',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      print(response.data);
      if (response.statusCode == 200) {
        profileData = profileFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in profile api");
      return false;
    }
  }

  Future<bool> editProfile({
    required String regno,
    required String firstname,
    required String lastname,
    required String phonenum,
    required String role,
  }) async {
    try {
      var formData = {
        "regno": regno,
        "firstname": firstname,
        "lastname": lastname,
        "phonenum": phonenum,
        "role": role,
      };
      Response response = await Dio().put(
        'https://api421.herokuapp.com/profile/update/email/${profileData.first.email}',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        profileData.first.name = firstname + lastname;
        profileData.first.phone = phonenum;
        profileData.first.regno = regno;
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> changePassword(
      {required String email, required String password}) async {
    try {
      var formData = {"password": password};
      Response response = await Dio().put(
        'https://api421.herokuapp.com/login/email/$email/updatepassword',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

//------------------------ Fetch Evaluation Form Details ---------------------

  Future<bool> getStudentEvaluation(
      {required String studentid, required int competencyid}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/competencyevaluations/competencyid/$competencyid/studentid/$studentid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      print("updated");
      if (response.statusCode == 200) {
        studentEvaluation =
            studentEvaluationFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in login check");
      return false;
    }
  }

  Future<bool> getEvaluationForm(
      {required int competencyevaluationid, required int competencyid}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/competencyevaluations/competencyid/$competencyid/competencyevaluationid/$competencyevaluationid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        evaluationForm = EvaluationForm.fromJson(response.data);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in login check");
      return false;
    }
  }

//------------------------ View Submitted Evaluation Form ---------------------

  Future<bool> checkEvaluationForm(
      {required int competencyevaluationid, required int competencyid}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/competencyevaluations/facultyview/competencyid/$competencyid/competencyevaluationid/$competencyevaluationid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      print(response.data);
      if (response.statusCode == 200) {
        seeEvaluationForm = SeeEvaluationForm.fromJson(response.data);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in login check");
      return false;
    }
  }

  Future<bool> checkStudentEvaluationForm(
      {required int competencyevaluationid, required int competencyid}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/competencyevaluations/selfview/competencyid/$competencyid/competencyevaluationid/$competencyevaluationid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        seeStudentEvaluation = SeeStudentEvaluation.fromJson(response.data);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in login check");
      return false;
    }
  }

//------------------------Create new row (Only Faculty) ----------------------
  Future<bool> createUser(
      {required String opnum,
      required String fmail,
      required int competencyid,
      required String studentid}) async {
    try {
      var formData = {"opnum": opnum, "fmail": fmail};
      Response response = await Dio().post(
        'https://api421.herokuapp.com/competencyevaluations/competencyid/$competencyid/studentid/$studentid/opnum',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getStudentEvaluation(
            studentid: studentid, competencyid: competencyid);
        if (k) {
          //TODO Notification
          notifyListeners();
          return true;
        }
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

//------------------------Submit the Form ------------------------------------

  Future<bool> submitEvaluationForm({
    required int competencyevaluationid,
    required var formData,
    required String studentid,
    required int competencyid,
  }) async {
    try {
      Response response = await Dio().post(
        'https://api421.herokuapp.com/competencyevaluations/competencyevaluationid/$competencyevaluationid',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getStudentEvaluation(
            studentid: studentid, competencyid: competencyid);
        k = await getCompetencyDetailsList(
          speciality: specialityForEvaluation,
          competencyid: competencyid,
        );
        notifyListeners();
        return k;
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

  Future<bool> submitStudentEvaluationForm({
    required int competencyevaluationid,
    required var formData,
    required String studentid,
    required int competencyid,
  }) async {
    try {
      Response response = await Dio().post(
        'https://api421.herokuapp.com/competencyevaluations/self/competencyevaluationid/$competencyevaluationid',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getStudentEvaluation(
            studentid: studentid, competencyid: competencyid);
        k = await getCompetencyDetailsList(
          speciality: specialityForEvaluation,
          competencyid: competencyid,
        );
        notifyListeners();
        return k;
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

//----------------------- Faculty Todo ----------------------------------

  Future<bool> getOne2OneList({required String mail}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/facultytodo/meet/$mail',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        one2oneList = one2OneMeetFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> getReferenceList({required String mail}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/facultytodo/reference/$mail',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );

      if (response.statusCode == 200) {
        print(response);
        referenceList = referenceNeededFromJson(json.encode(response.data));
        referenceStudentList.sort((b, a) => DateTime.parse(
                "${a.datetime.split(" ")[0].split("-")[2]}-${a.datetime.split(" ")[0].split("-")[1]}-${a.datetime.split(" ")[0].split("-")[0]}")
            .compareTo(DateTime.parse(
                "${b.datetime.split(" ")[0].split("-")[2]}-${b.datetime.split(" ")[0].split("-")[1]}-${b.datetime.split(" ")[0].split("-")[0]}")));

        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> submitOne2One({required var formData}) async {
    try {
      Response response = await Dio().post(
        'https://api421.herokuapp.com/facultytodo/postmeet',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getOne2OneList(mail: profileData.first.email);
        if (k) {
          notifyListeners();
          return true;
        } else {
          return false;
        }
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

  Future<bool> submitReference({required var formData}) async {
    try {
      Response response = await Dio().post(
        'https://api421.herokuapp.com/facultytodo/postrefernce',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getReferenceList(mail: profileData.first.email);
        if (k) {
          notifyListeners();
          return true;
        } else {
          return false;
        }
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

//----------------------- Student Todo ----------------------------------

  Future<bool> getOne2OneStudentList({required String mail}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/studenttodo/meet/$mail',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        one2oneStudentList =
            one2OneMeetStudentFromJson(json.encode(response.data));
        one2oneStudentList.sort((b, a) =>
            DateTime.parse(a.meettime.split(" ")[3])
                .compareTo(DateTime.parse(b.meettime.split(" ")[3])));

        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> getReferenceStudentList({required String mail}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/studenttodo/reference/$mail',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        referenceStudentList =
            referenceStudentListFromJson(json.encode(response.data));
        referenceStudentList.sort((b, a) => DateTime.parse(
                "${a.datetime.split(" ")[0].split("-")[2]}-${a.datetime.split(" ")[0].split("-")[1]}-${a.datetime.split(" ")[0].split("-")[0]}")
            .compareTo(DateTime.parse(
                "${b.datetime.split(" ")[0].split("-")[2]}-${b.datetime.split(" ")[0].split("-")[1]}-${b.datetime.split(" ")[0].split("-")[0]}")));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  //////////////////////////////////////////////////////////////////////////////////
  ///
  ///
  ///
  ///-----------------------------------Admin--------------------------------
  ///
  ///
  ////////////////////////////////////////////////////////////////////////////////////

  AllAdmins? allAdmins;
  List<AllFaculty> allfaculty = [];
  List<AllStudent> allstudent = [];
  List<Batches> allBatches = [];
  AllSpeciality? allSpeciality;
  AllCompetency? allCompetency;
  ViewCompetency? viewCompetency;

  Future<bool> getAllAdmins({required String mail}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/admin/getall/$mail',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        allAdmins = AllAdmins.fromJson(response.data);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in get All admins");
      return false;
    }
  }

  Future<bool> createAdmin({
    required String adminfirstname,
    required String adminlastname,
    required String password,
    required String phonenumber,
    required String mail,
  }) async {
    try {
      var formData = {
        "adminfirstname": adminfirstname,
        "adminlastname": adminlastname,
        "password": password,
        "phonenumber": phonenumber,
        "mail": mail,
      };
      Response response = await Dio().post(
        'https://api421.herokuapp.com/admin/insert',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllAdmins(mail: profileData.first.email);
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> updateAdmin({
    required String adminfirstname,
    required String adminlastname,
    required String password,
    required String phonenumber,
    required String mail,
    required int personid,
  }) async {
    try {
      var formData = {
        "adminfirstname": adminfirstname,
        "adminlastname": adminlastname,
        "password": password,
        "phonenumber": phonenumber,
        "mail": mail,
        "personid": personid,
      };
      Response response = await Dio().put(
        'https://api421.herokuapp.com/admin/update',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      print(response.data);
      print(response.statusCode);
      if (response.statusCode == 200) {
        bool k = await getAllAdmins(mail: profileData.first.email);
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteAdmin({required int personid}) async {
    try {
      Response response = await Dio().delete(
        'https://api421.herokuapp.com/admin/delete/$personid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllAdmins(mail: profileData.first.email);
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> getAllFaculty() async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/admin/faculty/getall',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        allfaculty = allFacultyFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in get All faculty");
      return false;
    }
  }

  Future<bool> createFaculty({
    required String specialityname,
    required String facultyid,
    required String facultyfirstname,
    required String facultylastname,
    required String password,
    required String phonenumber,
    required String mail,
  }) async {
    try {
      var formData = {
        "specialityname": specialityname,
        "facultyid": facultyid,
        "facultyfirstname": facultyfirstname,
        "facultylastname": facultylastname,
        "password": password,
        "phonenumber": phonenumber,
        "mail": mail,
      };
      Response response = await Dio().post(
        'https://api421.herokuapp.com/admin/faculty/insert',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllFaculty();
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> updateFaculty({
    required int personid,
    required String specialityname,
    required String facultyid,
    required String facultyfirstname,
    required String facultylastname,
    required String password,
    required String phonenumber,
    required String mail,
  }) async {
    try {
      var formData = {
        "personid": personid,
        "specialityname": specialityname,
        "facultyid": facultyid,
        "facultyfirstname": facultyfirstname,
        "facultylastname": facultylastname,
        "password": password,
        "phonenumber": phonenumber,
        "mail": mail,
      };
      Response response = await Dio().put(
        'https://api421.herokuapp.com/admin/faculty/update',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      print(response.data);
      print(response.statusCode);
      if (response.statusCode == 200) {
        bool k = await getAllFaculty();
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteFaculty({required int personid}) async {
    try {
      Response response = await Dio().delete(
        'https://api421.herokuapp.com/admin/faculty/delete/$personid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllFaculty();
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> getBatches() async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/admin/student/getbacthnames',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        allBatches = batchesFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in get All batches");
      return false;
    }
  }

  Future<bool> createBatch({required String batchName}) async {
    try {
      Response response = await Dio().post(
        'https://api421.herokuapp.com/admin/student/addbatch/$batchName',
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getBatches();
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> getAllStudents({required String batchName}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/admin/student/getall/$batchName',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        allstudent = allStudentFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in get All student");
      return false;
    }
  }

  Future<bool> createStudent({
    required String batchName,
    required String studentid,
    required String firstname,
    required String lastname,
    required String password,
    required String phonenum,
    required String email,
  }) async {
    try {
      var formData = {
        "studentid": studentid,
        "firstname": firstname,
        "lastname": lastname,
        "password": password,
        "phonenum": phonenum,
        "email": email,
      };
      Response response = await Dio().post(
        'https://api421.herokuapp.com/admin/student/add/batch/$batchName',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllStudents(batchName: batchName);
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> updateStudent({
    required int personid,
    required String batchName,
    required String studentid,
    required String firstname,
    required String lastname,
    required String password,
    required String phonenum,
    required String email,
  }) async {
    try {
      var formData = {
        "personid": personid,
        "studentid": studentid,
        "studentfirstname": firstname,
        "studentlastname": lastname,
        "password": password,
        "phonenumber": phonenum,
        "mail": email
      };
      Response response = await Dio().put(
        'https://api421.herokuapp.com/admin/student/update',
        data: formData,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllStudents(batchName: batchName);
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteStudent(
      {required int personid, required String batchName}) async {
    try {
      Response response = await Dio().delete(
        'https://api421.herokuapp.com/admin/student/delete/$personid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllStudents(batchName: batchName);
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> getAllSpeciality() async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/studentdashboard/specialities',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        allSpeciality = allSpecialityFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in get All speciality");
      return false;
    }
  }

  Future<bool> getAllComp({required String speciality}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/fdashboard/competencydetails/$speciality',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        allCompetency = allCompetencyFromJson(json.encode(response.data));
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print("error in get All competency");
      return false;
    }
  }

  Future<bool> createSpeciality({required String specialityname}) async {
    try {
      Response response = await Dio().post(
        'https://api421.herokuapp.com/admin/speciality/add/$specialityname',
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllSpeciality();
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> updateSpeciality({
    required int specialityid,
    required String specialityname,
  }) async {
    try {
      Response response = await Dio().put(
        'https://api421.herokuapp.com/admin/speciality/update/$specialityname/$specialityid',
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllSpeciality();
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> createCompetency({
    required String specialityname,
    required Map body,
  }) async {
    try {
      Response response = await Dio().post(
        'https://api421.herokuapp.com/admin/speciality/competency/add/$specialityname',
        data: body,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllComp(speciality: specialityname);
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> updateCompetency({
    required String specialityname,
    required Map body,
  }) async {
    try {
      Response response = await Dio().put(
        'https://api421.herokuapp.com/admin/speciality/competency/update',
        data: body,
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllComp(speciality: specialityname);
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteCompetency({required int competencyid}) async {
    try {
      Response response = await Dio().delete(
        'https://api421.herokuapp.com/admin/speciality/competency/delete/$competencyid',
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteCompetencyEvaluation({
    required int competencyevaluationid,
    required String studentid,
    required int competencyid,
  }) async {
    try {
      Response response = await Dio().delete(
        'https://api421.herokuapp.com/competencyevaluations/$competencyevaluationid',
        options: Options(
          headers: {'Content-Type': 'application/json', 'accept': '*/*'},
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getStudentEvaluation(
            studentid: studentid, competencyid: competencyid);
        k = await getCompetencyDetailsList(
          speciality: specialityForEvaluation,
          competencyid: competencyid,
        );
        return k;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> viewCompetencyData({required int competencyid}) async {
    try {
      Response response = await Dio().get(
        'https://api421.herokuapp.com/admin/speciality/competency/getcompetency/$competencyid',
        options: Options(
          followRedirects: false,
          validateStatus: (status) {
            return status! < 500;
          },
        ),
      );
      if (response.statusCode == 200) {
        viewCompetency = ViewCompetency.fromJson(response.data);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> addAdminBulk(FormData formData) async {
    try {
      Dio dio = Dio();
      dio.options.contentType = 'multipart/form-data';
      dio.options.headers = {
        'Content-Type': 'multipart/form-data',
        'accept': '*/*',
      };
      Response response = await dio.post(
        'https://api421.herokuapp.com/admin/addcsvfile',
        data: formData,
        options: Options(
          followRedirects: false,
          validateStatus: (status) => true,
        ),
      );

      if (response.statusCode == 200) {
        bool k = await getAllAdmins(mail: profileData.first.email);
        return k;
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

  Future<bool> addFacultyBulk(FormData formData) async {
    try {
      Dio dio = Dio();
      dio.options.contentType = 'multipart/form-data';
      dio.options.headers = {
        'Content-Type': 'multipart/form-data',
        'accept': '*/*',
      };
      Response response = await dio.post(
        'https://api421.herokuapp.com/admin/faculty/addcsvfile',
        data: formData,
        options: Options(
          followRedirects: false,
          validateStatus: (status) => true,
        ),
      );
      if (response.statusCode == 200) {
        bool k = await getAllFaculty();
        return k;
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

  Future<bool> addStudentBulk(FormData formData,
      {required String batchName}) async {
    try {
      Dio dio = Dio();
      dio.options.contentType = 'multipart/form-data';
      dio.options.headers = {
        'Content-Type': 'multipart/form-data',
        'accept': '*/*',
      };
      Response response = await dio.post(
        'https://api421.herokuapp.com/admin/student/addcsvfile/$batchName',
        data: formData,
        options: Options(
          followRedirects: false,
          validateStatus: (status) => true,
        ),
      );

      if (response.statusCode == 200) {
        bool k = await getAllStudents(batchName: batchName);
        return k;
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }
}
