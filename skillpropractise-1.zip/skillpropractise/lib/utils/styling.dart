import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:google_fonts/google_fonts.dart';

HexColor primaryColor = HexColor('#0C4F8C');
MaterialColor secondaryColor = Colors.indigo;
// TextStyle primaryFontStyle = GoogleFonts.baloo(
//   letterSpacing: 5,
//   fontSize: 30,
// );
// TextStyle secondaryFontStyle = GoogleFonts.poppins();
TextStyle baloo = GoogleFonts.baloo();
TextStyle poppins = GoogleFonts.poppins();
