import 'package:firstskillpro/Services/api.dart';
import 'package:firstskillpro/utils/dialogues.dart';
import 'package:firstskillpro/utils/styling.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

//------------------ Admin --------------------------
void show({
  required BuildContext context,
  required String firstName,
  required String lastName,
  required String email,
  required String password,
  required String phone,
  required int personid,
}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  bool loading = false;
  bool loadingDelete = false;
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: ListView(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextFormField(
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: firstName,
                          onChanged: (e) {
                            setState(() {
                              firstName = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "First Name",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.name,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: lastName,
                          onChanged: (e) {
                            setState(() {
                              lastName = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Last Name",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: email,
                          onChanged: (e) {
                            setState(() {
                              email = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Email",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: password,
                          onChanged: (e) {
                            setState(() {
                              password = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Password",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.digitsOnly
                          ],
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: phone,
                          onChanged: (e) {
                            setState(() {
                              phone = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Phone",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
              actions: <Widget>[
                Column(
                  children: [
                    const Divider(
                      height: 10.00,
                      thickness: 1.00,
                      color: Colors.black26,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          InkWell(
                            onTap: loadingDelete
                                ? () {}
                                : () async {
                                    setState(() {
                                      loadingDelete = true;
                                    });
                                    bool k = await obj.deleteAdmin(
                                      personid: personid,
                                    );
                                    if (k) {
                                      Navigator.of(context).pop();
                                      CustomSnackBar(
                                        context,
                                        const Text(
                                          "Deleted SuccessFully",
                                        ),
                                      );
                                    } else {
                                      setState(() {
                                        loadingDelete = false;
                                      });
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loadingDelete
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Delete",
                                      ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: loading
                                ? () {}
                                : () async {
                                    setState(() {
                                      loading = true;
                                    });
                                    bool k = await obj.updateAdmin(
                                      adminfirstname: firstName,
                                      adminlastname: lastName,
                                      password: password,
                                      phonenumber: phone,
                                      mail: email,
                                      personid: personid,
                                    );
                                    if (k) {
                                      Navigator.of(context).pop();
                                      CustomSnackBar(
                                        context,
                                        const Text(
                                          "Updated SuccessFully",
                                        ),
                                      );
                                    } else {
                                      setState(() {
                                        loading = false;
                                      });
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loading
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Update",
                                      ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

void add({required BuildContext context}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  final _formKey = GlobalKey<FormState>();
  bool loading = false;
  String firstName = "";
  String lastName = "";
  String email = "";
  String password = "";
  String phone = "";
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 5),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: firstName,
                            onChanged: (e) {
                              setState(() {
                                firstName = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "First Name",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.name,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: lastName,
                            onChanged: (e) {
                              setState(() {
                                lastName = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Last Name",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.emailAddress,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: email,
                            onChanged: (e) {
                              setState(() {
                                email = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Email",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: password,
                            onChanged: (e) {
                              setState(() {
                                password = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Password",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.number,
                            inputFormatters: <TextInputFormatter>[
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: phone,
                            onChanged: (e) {
                              setState(() {
                                phone = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Phone",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              actions: <Widget>[
                Column(
                  children: [
                    const Divider(
                      height: 10.00,
                      thickness: 1.00,
                      color: Colors.black26,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          InkWell(
                            onTap: loading
                                ? () {}
                                : () async {
                                    if (_formKey.currentState!.validate()) {
                                      _formKey.currentState!.save();

                                      setState(() {
                                        loading = true;
                                      });
                                      bool k = await obj.createAdmin(
                                        adminfirstname: firstName,
                                        adminlastname: lastName,
                                        password: password,
                                        phonenumber: phone,
                                        mail: email,
                                      );
                                      if (k) {
                                        Navigator.of(context).pop();
                                        CustomSnackBar(
                                          context,
                                          const Text(
                                            "Admin Created SuccessFully",
                                          ),
                                        );
                                      } else {
                                        setState(() {
                                          loading = false;
                                        });
                                      }
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loading
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Submit",
                                      ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

//------------------ Faculty --------------------------

void showFaculty({
  required BuildContext context,
  required int personid,
  required String facultyid,
  required String firstName,
  required String lastName,
  required String email,
  required String password,
  required String phone,
  required String speciality,
}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  bool loading = false;
  bool loadingDelete = false;
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: ListView(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextFormField(
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: firstName,
                          onChanged: (e) {
                            setState(() {
                              firstName = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "First Name",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.name,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: lastName,
                          onChanged: (e) {
                            setState(() {
                              lastName = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Last Name",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: email,
                          onChanged: (e) {
                            setState(() {
                              email = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Email",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: password,
                          onChanged: (e) {
                            setState(() {
                              password = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Password",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.digitsOnly
                          ],
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: phone,
                          onChanged: (e) {
                            setState(() {
                              phone = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Phone",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: speciality,
                          onChanged: (e) {
                            setState(() {
                              speciality = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Speaciality",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
              actions: <Widget>[
                Column(
                  children: [
                    const Divider(
                      height: 10.00,
                      thickness: 1.00,
                      color: Colors.black26,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          InkWell(
                            onTap: loadingDelete
                                ? () {}
                                : () async {
                                    setState(() {
                                      loadingDelete = true;
                                    });
                                    bool k = await obj.deleteFaculty(
                                      personid: personid,
                                    );
                                    if (k) {
                                      Navigator.of(context).pop();
                                      CustomSnackBar(
                                        context,
                                        const Text(
                                          "Deleted SuccessFully",
                                        ),
                                      );
                                    } else {
                                      setState(() {
                                        loadingDelete = false;
                                      });
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loadingDelete
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Delete",
                                      ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: loading
                                ? () {}
                                : () async {
                                    setState(() {
                                      loading = true;
                                    });
                                    bool k = await obj.updateFaculty(
                                      personid: personid,
                                      specialityname: speciality,
                                      facultyid: facultyid,
                                      facultyfirstname: firstName,
                                      facultylastname: lastName,
                                      password: password,
                                      phonenumber: phone,
                                      mail: email,
                                    );
                                    if (k) {
                                      Navigator.of(context).pop();
                                      CustomSnackBar(
                                        context,
                                        const Text(
                                          "Updated SuccessFully",
                                        ),
                                      );
                                    } else {
                                      setState(() {
                                        loading = false;
                                      });
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loading
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Update",
                                      ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

void addFaculty({required BuildContext context}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  final _formKey = GlobalKey<FormState>();
  bool loading = false;
  String firstName = "";
  String lastName = "";
  String email = "";
  String password = "";
  String phone = "";
  String specialityname = "";
  String facultyid = "";
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 5),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: facultyid,
                            onChanged: (e) {
                              setState(() {
                                facultyid = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Faculty ID",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: specialityname,
                            onChanged: (e) {
                              setState(() {
                                specialityname = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Speaciality",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: firstName,
                            onChanged: (e) {
                              setState(() {
                                firstName = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "First Name",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.name,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: lastName,
                            onChanged: (e) {
                              setState(() {
                                lastName = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Last Name",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.emailAddress,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: email,
                            onChanged: (e) {
                              setState(() {
                                email = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Email",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: password,
                            onChanged: (e) {
                              setState(() {
                                password = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Password",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.number,
                            inputFormatters: <TextInputFormatter>[
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: phone,
                            onChanged: (e) {
                              setState(() {
                                phone = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Phone",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              actions: <Widget>[
                Column(
                  children: [
                    const Divider(
                      height: 10.00,
                      thickness: 1.00,
                      color: Colors.black26,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          InkWell(
                            onTap: loading
                                ? () {}
                                : () async {
                                    if (_formKey.currentState!.validate()) {
                                      _formKey.currentState!.save();

                                      setState(() {
                                        loading = true;
                                      });
                                      bool k = await obj.createFaculty(
                                        specialityname: specialityname,
                                        facultyid: facultyid,
                                        facultyfirstname: firstName,
                                        facultylastname: lastName,
                                        password: password,
                                        phonenumber: phone,
                                        mail: email,
                                      );
                                      if (k) {
                                        Navigator.of(context).pop();
                                        CustomSnackBar(
                                          context,
                                          const Text(
                                            "Faculty Created SuccessFully",
                                          ),
                                        );
                                      } else {
                                        setState(() {
                                          loading = false;
                                        });
                                      }
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loading
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Submit",
                                      ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

//------------------ Batch --------------------------
void addBatch({required BuildContext context}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  final _formKey = GlobalKey<FormState>();
  bool loading = false;
  String start = "";
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 5),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[
                          FilteringTextInputFormatter.digitsOnly
                        ],
                        validator: (val) {
                          if (val!.isEmpty) {
                            return "* Required Field";
                          } else {
                            return null;
                          }
                        },
                        initialValue: start,
                        onChanged: (e) {
                          setState(() {
                            start = e;
                          });
                        },
                        style: const TextStyle(
                            fontSize: 16.0, color: Colors.black),
                        decoration: InputDecoration(
                          labelText: "Starting Year",
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5)),
                          labelStyle: const TextStyle(
                              fontSize: 17.0, color: Colors.black),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      InkWell(
                        onTap: loading
                            ? () {}
                            : () async {
                                if (_formKey.currentState!.validate()) {
                                  _formKey.currentState!.save();

                                  setState(() {
                                    loading = true;
                                  });
                                  bool k =
                                      await obj.createBatch(batchName: start);
                                  if (k) {
                                    Navigator.of(context).pop();
                                    CustomSnackBar(
                                      context,
                                      const Text(
                                        "Batch Created SuccessFully",
                                      ),
                                    );
                                  } else {
                                    setState(() {
                                      loading = false;
                                    });
                                  }
                                }
                              },
                        child: Container(
                          height: 40,
                          width: MediaQuery.of(context).size.width / 3,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              width: 1,
                              color: Colors.black,
                            ),
                          ),
                          child: Center(
                            child: loading
                                ? const CircularProgressIndicator()
                                : const Text(
                                    "Submit",
                                  ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

//------------------ Student --------------------------

void showStudent({
  required BuildContext context,
  required int personid,
  required String batchName,
  required String studentId,
  required String firstName,
  required String lastName,
  required String email,
  required String password,
  required String phone,
}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  bool loading = false;
  bool loadingDelete = false;
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: ListView(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextFormField(
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: studentId,
                          onChanged: (e) {
                            setState(() {
                              studentId = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "RegNo.",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: firstName,
                          onChanged: (e) {
                            setState(() {
                              firstName = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "First Name",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.name,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: lastName,
                          onChanged: (e) {
                            setState(() {
                              lastName = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Last Name",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: email,
                          onChanged: (e) {
                            setState(() {
                              email = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Email",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: password,
                          onChanged: (e) {
                            setState(() {
                              password = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Password",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.digitsOnly
                          ],
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "* Required Field";
                            } else {
                              return null;
                            }
                          },
                          initialValue: phone,
                          onChanged: (e) {
                            setState(() {
                              phone = e;
                            });
                          },
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: "Phone",
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5)),
                            labelStyle: const TextStyle(
                                fontSize: 17.0, color: Colors.black),
                          ),
                        ),
                        const SizedBox(height: 10),
                      ],
                    ),
                  )
                ],
              ),
              actions: <Widget>[
                Column(
                  children: [
                    const Divider(
                      height: 10.00,
                      thickness: 1.00,
                      color: Colors.black26,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          InkWell(
                            onTap: loadingDelete
                                ? () {}
                                : () async {
                                    setState(() {
                                      loadingDelete = true;
                                    });
                                    bool k = await obj.deleteStudent(
                                      personid: personid,
                                      batchName: batchName,
                                    );
                                    if (k) {
                                      Navigator.of(context).pop();
                                      CustomSnackBar(
                                        context,
                                        const Text(
                                          "Deleted SuccessFully",
                                        ),
                                      );
                                    } else {
                                      setState(() {
                                        loadingDelete = false;
                                      });
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loadingDelete
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Delete",
                                      ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: loading
                                ? () {}
                                : () async {
                                    setState(() {
                                      loading = true;
                                    });
                                    bool k = await obj.updateStudent(
                                      personid: personid,
                                      batchName: batchName,
                                      studentid: studentId,
                                      firstname: firstName,
                                      lastname: lastName,
                                      password: password,
                                      phonenum: phone,
                                      email: email,
                                    );
                                    if (k) {
                                      Navigator.of(context).pop();
                                      CustomSnackBar(
                                        context,
                                        const Text(
                                          "Updated SuccessFully",
                                        ),
                                      );
                                    } else {
                                      setState(() {
                                        loading = false;
                                      });
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loading
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Update",
                                      ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

void addStudent({required BuildContext context, required String batchName}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  final _formKey = GlobalKey<FormState>();
  bool loading = false;
  String regNo = "";
  String firstName = "";
  String lastName = "";
  String email = "";
  String password = "";
  String phone = "";
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 5),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: regNo,
                            onChanged: (e) {
                              setState(() {
                                regNo = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "RegNo.",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: firstName,
                            onChanged: (e) {
                              setState(() {
                                firstName = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "First Name",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.name,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: lastName,
                            onChanged: (e) {
                              setState(() {
                                lastName = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Last Name",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.emailAddress,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: email,
                            onChanged: (e) {
                              setState(() {
                                email = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Email",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: password,
                            onChanged: (e) {
                              setState(() {
                                password = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Password",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            keyboardType: TextInputType.number,
                            inputFormatters: <TextInputFormatter>[
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "* Required Field";
                              } else {
                                return null;
                              }
                            },
                            initialValue: phone,
                            onChanged: (e) {
                              setState(() {
                                phone = e;
                              });
                            },
                            style: const TextStyle(
                                fontSize: 16.0, color: Colors.black),
                            decoration: InputDecoration(
                              labelText: "Phone",
                              floatingLabelBehavior:
                                  FloatingLabelBehavior.always,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(5)),
                              labelStyle: const TextStyle(
                                  fontSize: 17.0, color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              actions: <Widget>[
                Column(
                  children: [
                    const Divider(
                      height: 10.00,
                      thickness: 1.00,
                      color: Colors.black26,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          InkWell(
                            onTap: loading
                                ? () {}
                                : () async {
                                    if (_formKey.currentState!.validate()) {
                                      _formKey.currentState!.save();

                                      setState(() {
                                        loading = true;
                                      });
                                      bool k = await obj.createStudent(
                                        batchName: batchName,
                                        studentid: regNo,
                                        firstname: firstName,
                                        lastname: lastName,
                                        password: password,
                                        phonenum: phone,
                                        email: email,
                                      );
                                      if (k) {
                                        Navigator.of(context).pop();
                                        CustomSnackBar(
                                          context,
                                          const Text(
                                            "Student Created SuccessFully",
                                          ),
                                        );
                                      } else {
                                        setState(() {
                                          loading = false;
                                        });
                                      }
                                    }
                                  },
                            child: Container(
                              height: 40,
                              width: MediaQuery.of(context).size.width / 3,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.black,
                                ),
                              ),
                              child: Center(
                                child: loading
                                    ? const CircularProgressIndicator()
                                    : const Text(
                                        "Submit",
                                      ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

//------------------ Speciality-------------------------

void addSpeciality({required BuildContext context}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  final _formKey = GlobalKey<FormState>();
  bool loading = false;
  String speciality = "";
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 5),
                      child: TextFormField(
                        keyboardType: TextInputType.name,
                        validator: (val) {
                          if (val!.isEmpty) {
                            return "* Required Field";
                          } else {
                            return null;
                          }
                        },
                        initialValue: speciality,
                        onChanged: (e) {
                          setState(() {
                            speciality = e;
                          });
                        },
                        style: const TextStyle(
                            fontSize: 16.0, color: Colors.black),
                        decoration: InputDecoration(
                          labelText: "Speciality",
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5)),
                          labelStyle: const TextStyle(
                              fontSize: 17.0, color: Colors.black),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      InkWell(
                        onTap: loading
                            ? () {}
                            : () async {
                                if (_formKey.currentState!.validate()) {
                                  _formKey.currentState!.save();

                                  setState(() {
                                    loading = true;
                                  });
                                  bool k = await obj.createSpeciality(
                                      specialityname: speciality);
                                  if (k) {
                                    Navigator.of(context).pop();
                                    CustomSnackBar(
                                      context,
                                      const Text(
                                        "Speciality Created SuccessFully",
                                      ),
                                    );
                                  } else {
                                    setState(() {
                                      loading = false;
                                    });
                                  }
                                }
                              },
                        child: Container(
                          height: 40,
                          width: MediaQuery.of(context).size.width / 3,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              width: 1,
                              color: Colors.black,
                            ),
                          ),
                          child: Center(
                            child: loading
                                ? const CircularProgressIndicator()
                                : const Text(
                                    "Submit",
                                  ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

void showSpeciality({
  required BuildContext context,
  required int specialityid,
  required String specialityname,
}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  final _formKey = GlobalKey<FormState>();
  bool loading = false;
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 5),
                      child: TextFormField(
                        keyboardType: TextInputType.name,
                        validator: (val) {
                          if (val!.isEmpty) {
                            return "* Required Field";
                          } else {
                            return null;
                          }
                        },
                        initialValue: specialityname,
                        onChanged: (e) {
                          setState(() {
                            specialityname = e;
                          });
                        },
                        style: const TextStyle(
                            fontSize: 16.0, color: Colors.black),
                        decoration: InputDecoration(
                          labelText: "Speciality",
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5)),
                          labelStyle: const TextStyle(
                              fontSize: 17.0, color: Colors.black),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      InkWell(
                        onTap: loading
                            ? () {}
                            : () async {
                                if (_formKey.currentState!.validate()) {
                                  _formKey.currentState!.save();

                                  setState(() {
                                    loading = true;
                                  });
                                  bool k = await obj.updateSpeciality(
                                    specialityid: specialityid,
                                    specialityname: specialityname,
                                  );
                                  if (k) {
                                    Navigator.of(context).pop();
                                    CustomSnackBar(
                                      context,
                                      const Text(
                                        "Speciality Updated SuccessFully",
                                      ),
                                    );
                                  } else {
                                    setState(() {
                                      loading = false;
                                    });
                                  }
                                }
                              },
                        child: Container(
                          height: 40,
                          width: MediaQuery.of(context).size.width / 3,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              width: 1,
                              color: Colors.black,
                            ),
                          ),
                          child: Center(
                            child: loading
                                ? const CircularProgressIndicator()
                                : const Text(
                                    "Submit",
                                  ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

void addCompetency(
    {required BuildContext context, required String specialityName}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  final _formKey = GlobalKey<FormState>();
  bool loading = false;
  String competencyName = "";
  List<Map<String, String>> criteriadetails = [
    {"criteriaqs": "", "option0": "", "option1": "", "option2": ""},
  ];
  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16.0)),
              content: Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  children: [
                    TextFormField(
                      keyboardType: TextInputType.name,
                      validator: (val) {
                        if (val!.isEmpty) {
                          return "* Required Field";
                        } else {
                          return null;
                        }
                      },
                      initialValue: competencyName,
                      onChanged: (e) {
                        setState(() {
                          competencyName = e;
                        });
                      },
                      style:
                          const TextStyle(fontSize: 16.0, color: Colors.black),
                      decoration: InputDecoration(
                        labelText: "Enter Competency",
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5)),
                        labelStyle: const TextStyle(
                            fontSize: 17.0, color: Colors.black),
                      ),
                    ),
                    const SizedBox(height: 10),
                    ...criteriadetails.map((element) {
                      return Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: TextFormField(
                                  keyboardType: TextInputType.name,
                                  validator: (val) {
                                    if (val!.isEmpty) {
                                      return "* Required Field";
                                    } else {
                                      return null;
                                    }
                                  },
                                  initialValue: element['criteriaqs'],
                                  onChanged: (e) {
                                    setState(() {
                                      int index =
                                          criteriadetails.indexOf(element);
                                      criteriadetails[index]['criteriaqs'] = e;
                                    });
                                  },
                                  style: const TextStyle(
                                      fontSize: 16.0, color: Colors.black),
                                  decoration: InputDecoration(
                                    labelText: "Enter Question",
                                    floatingLabelBehavior:
                                        FloatingLabelBehavior.always,
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(5)),
                                    labelStyle: const TextStyle(
                                        fontSize: 17.0, color: Colors.black),
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    criteriadetails.add({
                                      "criteriaqs": "",
                                      "option0": "",
                                      "option1": "",
                                      "option2": ""
                                    });
                                  });
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.add_circle,
                                    color: primaryColor,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 5),
                            child: Column(
                              children: [
                                TextFormField(
                                  keyboardType: TextInputType.name,
                                  validator: (val) {
                                    if (val!.isEmpty) {
                                      return "* Required Field";
                                    } else {
                                      return null;
                                    }
                                  },
                                  initialValue: element['option0'],
                                  onChanged: (e) {
                                    setState(() {
                                      int index =
                                          criteriadetails.indexOf(element);
                                      criteriadetails[index]['option0'] = e;
                                    });
                                  },
                                  style: const TextStyle(
                                      fontSize: 16.0, color: Colors.black),
                                  decoration: const InputDecoration(
                                    hintText: "Option 0",
                                    hintStyle: TextStyle(
                                        fontSize: 15.0, color: Colors.grey),
                                  ),
                                ),
                                const SizedBox(height: 10),
                                TextFormField(
                                  keyboardType: TextInputType.name,
                                  validator: (val) {
                                    if (val!.isEmpty) {
                                      return "* Required Field";
                                    } else {
                                      return null;
                                    }
                                  },
                                  initialValue: element['option1'],
                                  onChanged: (e) {
                                    setState(() {
                                      int index =
                                          criteriadetails.indexOf(element);
                                      criteriadetails[index]['option1'] = e;
                                    });
                                  },
                                  style: const TextStyle(
                                      fontSize: 16.0, color: Colors.black),
                                  decoration: const InputDecoration(
                                    hintText: "Option 1",
                                    hintStyle: TextStyle(
                                        fontSize: 15.0, color: Colors.grey),
                                  ),
                                ),
                                const SizedBox(height: 10),
                                TextFormField(
                                  keyboardType: TextInputType.name,
                                  validator: (val) {
                                    if (val!.isEmpty) {
                                      return "* Required Field";
                                    } else {
                                      return null;
                                    }
                                  },
                                  initialValue: element['option2'],
                                  onChanged: (e) {
                                    setState(() {
                                      int index =
                                          criteriadetails.indexOf(element);
                                      criteriadetails[index]['option2'] = e;
                                    });
                                  },
                                  style: const TextStyle(
                                      fontSize: 16.0, color: Colors.black),
                                  decoration: const InputDecoration(
                                    hintText: "Option 2",
                                    hintStyle: TextStyle(
                                        fontSize: 15.0, color: Colors.grey),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                        ],
                      );
                    }).toList(growable: true),
                  ],
                ),
              ),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      InkWell(
                        onTap: loading
                            ? () {}
                            : () async {
                                if (_formKey.currentState!.validate()) {
                                  _formKey.currentState!.save();

                                  setState(() {
                                    loading = true;
                                  });
                                  criteriadetails.removeWhere(
                                      (e) => e["criteriaqs"] == "");
                                  bool k = await obj.createCompetency(
                                    specialityname: specialityName,
                                    body: {
                                      "competencyname": competencyName,
                                      "criteriadetails": criteriadetails,
                                    },
                                  );
                                  if (k) {
                                    Navigator.of(context).pop();
                                    CustomSnackBar(
                                      context,
                                      const Text(
                                        "Speciality Created SuccessFully",
                                      ),
                                    );
                                  } else {
                                    setState(() {
                                      loading = false;
                                    });
                                  }
                                }
                              },
                        child: Container(
                          height: 40,
                          width: MediaQuery.of(context).size.width / 3,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              width: 1,
                              color: Colors.black,
                            ),
                          ),
                          child: Center(
                            child: loading
                                ? const CircularProgressIndicator()
                                : const Text(
                                    "Submit",
                                  ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}

void showCompetency(
    {required BuildContext context, required String specialityName}) {
  Api obj;
  obj = Provider.of<Api>(context, listen: false);
  final _formKey = GlobalKey<FormState>();
  bool loading = false;

  showGeneralDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    barrierDismissible: true,
    transitionBuilder: (context, a1, a2, widget) {
      return Transform.scale(
        scale: a1.value,
        child: Opacity(
          opacity: a1.value,
          child: StatefulBuilder(
            builder: (context, setState) {
              // void removeItem(int index) {
              //   setState(() {
              //     obj.viewCompetency!.criteriadetails =
              //         List.from(obj.viewCompetency!.criteriadetails)
              //           ..removeAt(index);
              //   });
              // }

              return AlertDialog(
                shape: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16.0)),
                content: Form(
                  key: _formKey,
                  child: ListView(
                    shrinkWrap: true,
                    physics: const BouncingScrollPhysics(),
                    children: [
                      TextFormField(
                        keyboardType: TextInputType.name,
                        validator: (val) {
                          if (val!.isEmpty) {
                            return "* Required Field";
                          } else {
                            return null;
                          }
                        },
                        initialValue: obj.viewCompetency!.competencyname,
                        onChanged: (e) {
                          setState(() {
                            obj.viewCompetency!.competencyname = e;
                          });
                        },
                        style: const TextStyle(
                            fontSize: 16.0, color: Colors.black),
                        decoration: InputDecoration(
                          labelText: "Competency",
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5)),
                          labelStyle: const TextStyle(
                              fontSize: 17.0, color: Colors.black),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: obj.viewCompetency!.criteriadetails.length,
                        itemBuilder: (context, i) {
                          return Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      keyboardType: TextInputType.name,
                                      validator: (val) {
                                        if (val!.isEmpty) {
                                          return "* Required Field";
                                        } else {
                                          return null;
                                        }
                                      },
                                      initialValue: obj.viewCompetency!
                                          .criteriadetails[i].criteriaqs,
                                      onChanged: (e) {
                                        setState(() {
                                          obj.viewCompetency!.criteriadetails[i]
                                              .criteriaqs = e;
                                        });
                                      },
                                      style: const TextStyle(
                                          fontSize: 16.0, color: Colors.black),
                                      decoration: InputDecoration(
                                        labelText: "Question",
                                        floatingLabelBehavior:
                                            FloatingLabelBehavior.always,
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(5)),
                                        labelStyle: const TextStyle(
                                            fontSize: 17.0,
                                            color: Colors.black),
                                      ),
                                    ),
                                  ),
                                  // obj.viewCompetency!.criteriadetails.length > 1
                                  //     ? InkWell(
                                  //         onTap: () {
                                  //           removeItem(i);
                                  //         },
                                  //         child: Padding(
                                  //           padding: const EdgeInsets.all(8.0),
                                  //           child: Icon(
                                  //             Icons.remove_circle,
                                  //             color: primaryColor,
                                  //             size: 30,
                                  //           ),
                                  //         ),
                                  //       )
                                  //     : Container(),
                                ],
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 5),
                                child: Column(
                                  children: [
                                    TextFormField(
                                      keyboardType: TextInputType.name,
                                      validator: (val) {
                                        if (val!.isEmpty) {
                                          return "* Required Field";
                                        } else {
                                          return null;
                                        }
                                      },
                                      initialValue: obj.viewCompetency!
                                          .criteriadetails[i].option0,
                                      onChanged: (e) {
                                        setState(() {
                                          obj.viewCompetency!.criteriadetails[i]
                                              .option0 = e;
                                        });
                                      },
                                      style: const TextStyle(
                                          fontSize: 16.0, color: Colors.black),
                                      decoration: const InputDecoration(
                                        hintText: "Option 0",
                                        hintStyle: TextStyle(
                                            fontSize: 15.0, color: Colors.grey),
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    TextFormField(
                                      keyboardType: TextInputType.name,
                                      validator: (val) {
                                        if (val!.isEmpty) {
                                          return "* Required Field";
                                        } else {
                                          return null;
                                        }
                                      },
                                      initialValue: obj.viewCompetency!
                                          .criteriadetails[i].option1,
                                      onChanged: (e) {
                                        setState(() {
                                          obj.viewCompetency!.criteriadetails[i]
                                              .option1 = e;
                                        });
                                      },
                                      style: const TextStyle(
                                          fontSize: 16.0, color: Colors.black),
                                      decoration: const InputDecoration(
                                        hintText: "Option 1",
                                        hintStyle: TextStyle(
                                            fontSize: 15.0, color: Colors.grey),
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    TextFormField(
                                      keyboardType: TextInputType.name,
                                      validator: (val) {
                                        if (val!.isEmpty) {
                                          return "* Required Field";
                                        } else {
                                          return null;
                                        }
                                      },
                                      initialValue: obj.viewCompetency!
                                          .criteriadetails[i].option2,
                                      onChanged: (e) {
                                        setState(() {
                                          obj.viewCompetency!.criteriadetails[i]
                                              .option2 = e;
                                        });
                                      },
                                      style: const TextStyle(
                                          fontSize: 16.0, color: Colors.black),
                                      decoration: const InputDecoration(
                                        hintText: "Option 2",
                                        hintStyle: TextStyle(
                                            fontSize: 15.0, color: Colors.grey),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 20),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                ),
                actions: <Widget>[
                  Column(
                    children: [
                      const Divider(
                        height: 10.00,
                        thickness: 1.00,
                        color: Colors.black26,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            InkWell(
                              onTap: loading
                                  ? () {}
                                  : () async {
                                      setState(() {
                                        loading = true;
                                      });
                                      bool k = await obj.updateCompetency(
                                          specialityname: specialityName,
                                          body: obj.viewCompetency!.toJson());
                                      if (k) {
                                        Navigator.of(context).pop();
                                        CustomSnackBar(
                                          context,
                                          const Text(
                                            "Updated SuccessFully",
                                          ),
                                        );
                                      } else {
                                        setState(() {
                                          loading = false;
                                        });
                                      }
                                    },
                              child: Container(
                                height: 40,
                                width: MediaQuery.of(context).size.width / 3,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    width: 1,
                                    color: Colors.black,
                                  ),
                                ),
                                child: Center(
                                  child: loading
                                      ? const CircularProgressIndicator()
                                      : const Text(
                                          "Update",
                                        ),
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: loading
                                  ? () {}
                                  : () async {
                                      setState(() {
                                        loading = true;
                                      });
                                      bool k = await obj.deleteCompetency(
                                        competencyid:
                                            obj.viewCompetency!.competencyid,
                                      );
                                      if (k) {
                                        obj.allCompetency!.details.removeWhere(
                                          (e) =>
                                              e.competencyid ==
                                              obj.viewCompetency!.competencyid,
                                        );
                                        obj.notify();
                                        Navigator.of(context).pop();
                                        CustomSnackBar(
                                          context,
                                          const Text(
                                            "Deleted SuccessFully",
                                          ),
                                        );
                                      } else {
                                        setState(() {
                                          loading = false;
                                        });
                                      }
                                    },
                              child: Container(
                                height: 40,
                                width: MediaQuery.of(context).size.width / 3,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    width: 1,
                                    color: Colors.black,
                                  ),
                                ),
                                child: Center(
                                  child: loading
                                      ? const CircularProgressIndicator()
                                      : const Text(
                                          "Delete",
                                        ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 200),
    barrierLabel: '',
    context: context,
    pageBuilder: (context, animation1, animation2) {
      return Container();
    },
  );
}
