import 'package:firstskillpro/Models/adminModels/allAdmins.dart';
import 'package:firstskillpro/Models/adminModels/allFaculty.dart';
import 'package:firstskillpro/Services/api.dart';
import 'package:firstskillpro/utils/adminInfo.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firstskillpro/utils/styling.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

class ManageSpeciality extends StatefulWidget {
  const ManageSpeciality({Key? key}) : super(key: key);

  @override
  State<ManageSpeciality> createState() => _ManageSpecialityState();
}

class _ManageSpecialityState extends State<ManageSpeciality> {
  bool first = true;
  bool loading = true;
  late Api obj;
  String? selectedSpeciality;
  bool fetchingComp = false;

  void getData() async {
    bool k = await obj.getAllSpeciality();
    if (k) {
      if (!mounted) return;
      setState(() {
        loading = false;
      });
    }
  }

  void getComp() async {
    setState(() {
      fetchingComp = true;
    });
    bool k = await obj.getAllComp(speciality: selectedSpeciality!);
    if (k) {
      if (!mounted) return;
      setState(() {
        fetchingComp = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    obj = Provider.of<Api>(context);
    if (first) {
      first = false;
      getData();
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: Text(
          "SKILLPRO",
          style: GoogleFonts.baloo(
            letterSpacing: 5,
            fontSize: 30,
          ),
        ),
        centerTitle: true,
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SizedBox(
              height: MediaQuery.of(context).size.height,
              child: Stack(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: 20,
                            horizontal: 10,
                          ),
                          child: Card(
                            elevation: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: Colors.blue.shade400,
                              ),
                              padding: const EdgeInsets.all(10),
                              height: 50,
                              width: MediaQuery.of(context).size.width,
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton(
                                  underline: DropdownButtonHideUnderline(
                                    child: Container(),
                                  ),
                                  iconEnabledColor: Colors.white,
                                  iconSize: selectedSpeciality == null ? 24 : 0,
                                  items: obj.allSpeciality!.details.map((type) {
                                    return DropdownMenuItem(
                                      child: SizedBox(
                                        width: selectedSpeciality == null
                                            ? MediaQuery.of(context)
                                                    .size
                                                    .width -
                                                80
                                            : MediaQuery.of(context)
                                                    .size
                                                    .width -
                                                50,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              type.specialityName,
                                              style: const TextStyle(
                                                fontSize: 16,
                                              ),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                showSpeciality(
                                                  context: context,
                                                  specialityid:
                                                      type.specialityId,
                                                  specialityname:
                                                      type.specialityName,
                                                );
                                                setState(() {
                                                  selectedSpeciality = null;
                                                });
                                              },
                                              child: Icon(
                                                Icons.edit,
                                                color: primaryColor,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      value: type.specialityName,
                                    );
                                  }).toList(),
                                  hint: const Text(
                                    "Choose a Speciality",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  style: GoogleFonts.poppins(
                                    color: Colors.black,
                                  ),
                                  value: selectedSpeciality,
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      selectedSpeciality = newValue!;
                                      getComp();
                                    });
                                  },
                                ),
                              ),
                            ),
                          ),
                        ),
                        fetchingComp
                            ? const Center(
                                child: CircularProgressIndicator(),
                              )
                            : obj.allCompetency == null ||
                                    selectedSpeciality == null
                                ? Container()
                                : ListView(
                                    shrinkWrap: true,
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    children: <Widget>[
                                      for (int i = 0;
                                          i < obj.allCompetency!.details.length;
                                          i++)
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: ElevatedButton(
                                            onPressed: () async {
                                              bool k =
                                                  await obj.viewCompetencyData(
                                                      competencyid: obj
                                                          .allCompetency!
                                                          .details[i]
                                                          .competencyid);
                                              if (k) {
                                                showCompetency(
                                                  context: context,
                                                  specialityName:
                                                      selectedSpeciality!,
                                                );
                                              }
                                            },
                                            child: Text(
                                              obj.allCompetency!.details[i]
                                                  .competencyname,
                                              style: GoogleFonts.poppins(
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: Column(
                        children: [
                          const Divider(
                            height: 10.00,
                            thickness: 1.00,
                            color: Colors.black26,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                InkWell(
                                  onTap: () {
                                    addSpeciality(context: context);
                                  },
                                  child: Container(
                                    height: 40,
                                    width:
                                        MediaQuery.of(context).size.width / 3,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade300,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        width: 1,
                                        color: Colors.black,
                                      ),
                                    ),
                                    child: const Center(
                                      child: Text(
                                        "Add Speciality",
                                      ),
                                    ),
                                  ),
                                ),
                                if (selectedSpeciality != null)
                                  InkWell(
                                    onTap: () {
                                      addCompetency(
                                        context: context,
                                        specialityName: selectedSpeciality!,
                                      );
                                    },
                                    child: Container(
                                      height: 40,
                                      width:
                                          MediaQuery.of(context).size.width / 3,
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade300,
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(
                                          width: 1,
                                          color: Colors.black,
                                        ),
                                      ),
                                      child: const Center(
                                        child: Text(
                                          "Add Competency",
                                        ),
                                      ),
                                    ),
                                  )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

//GridView to display the data as table
List<GridColumn> getColumn() {
  return <GridColumn>[
    GridColumn(
      columnName: 'Name',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('Name', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Email',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('Email', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Password',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child:
            Text('Password', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
  ];
}

class AdminsDataGridSource extends DataGridSource {
  AdminsDataGridSource(this.context, this.allFaculty) {
    buildDataGridRow();
  }
  late List<AllFaculty> allFaculty;
  late List<DataGridRow> dataGridRows;
  late BuildContext context;
  @override
  DataGridRowAdapter? buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      color: Colors.white,
      cells: [
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: TextButton(
            onPressed: () {
              AllFaculty faculty = allFaculty
                  .where((e) => e.email == row.getCells()[1].value)
                  .toList()
                  .first;
              showFaculty(
                context: context,
                personid: faculty.personid,
                facultyid: faculty.facultyid,
                firstName: faculty.firstname,
                lastName: faculty.lastname,
                email: faculty.email,
                password: faculty.password,
                phone: faculty.phone,
                speciality: faculty.speciality,
              );
            },
            child: Text(
              row.getCells()[0].value,
              style: poppins,
              textAlign: TextAlign.center,
              overflow: TextOverflow.visible,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[1].value,
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[2].value,
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
      ],
    );
  }

  @override
  List<DataGridRow> get rows => dataGridRows;
  void buildDataGridRow() {
    dataGridRows = allFaculty.map<DataGridRow>((dataGridRow) {
      return DataGridRow(
        cells: [
          DataGridCell<String>(
              columnName: 'Name',
              value: (dataGridRow.firstname + dataGridRow.lastname)),
          DataGridCell<String>(columnName: 'Email', value: dataGridRow.email),
          DataGridCell<String>(
              columnName: 'Password', value: dataGridRow.password),
        ],
      );
    }).toList(growable: true);
  }
}
