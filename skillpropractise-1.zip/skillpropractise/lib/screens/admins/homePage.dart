import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firstskillpro/Models/adminModels/allAdmins.dart';
import 'package:firstskillpro/Services/api.dart';
import 'package:firstskillpro/screens/admins/manageFaculty.dart';
import 'package:firstskillpro/screens/admins/manageSpeciality.dart';
import 'package:firstskillpro/screens/admins/manageStudent.dart';
import 'package:firstskillpro/utils/adminInfo.dart';
import 'package:firstskillpro/utils/dialogues.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firstskillpro/utils/styling.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:http_parser/http_parser.dart';

class AdminHomePage extends StatefulWidget {
  const AdminHomePage({Key? key}) : super(key: key);

  @override
  State<AdminHomePage> createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  bool first = true;
  bool loading = true;
  late Api obj;

  void getData() async {
    bool k = await obj.getAllAdmins(mail: obj.globalEmail);
    bool l = await obj.getProfile(email: obj.globalEmail);
    bool m = await obj.getBatches();
    if (k && l && m) {
      if (!mounted) return;
      setState(() {
        loading = false;
      });
    }
  }

  Future _onLogoutPressed() {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: const [
            Text("Are You Sure ?"),
          ],
        ),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: const [
            Text("You will be Logged Out"),
          ],
        ),
        actions: <Widget>[
          GestureDetector(
            onTap: () => Navigator.of(context).pop(false),
            child: const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text("No"),
            ),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () => Navigator.of(context).pop(true),
            child: const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text("Yes"),
            ),
          ),
        ],
      ),
    );
  }

  PlatformFile? file;
  bool loadingBulk = false;

  void _pickFiles() async {
    try {
      file = (await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv'],
        allowMultiple: false,
        onFileLoading: (FilePickerStatus status) => print(status),
      ))!
          .files
          .first;
      var formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file!.path!,
            filename: file!.path!.split('/').last,
            contentType: MediaType('multipart/form-data', 'csv')),
      });
      setState(() {
        loadingBulk = true;
      });
      bool k = await obj.addAdminBulk(formData);
      if (k) {
        setState(() {
          loadingBulk = false;
        });

        CustomSnackBar(
          context,
          const Text("Upload Success !!"),
        );
      } else {
        setState(() {
          loadingBulk = false;
        });
        CustomSnackBar(
          context,
          const Text("Error Occurred... "),
        );
      }
    } on PlatformException catch (e) {
      print('Unsupported operation' + e.toString());
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    obj = Provider.of<Api>(context);
    if (first) {
      first = false;
      getData();
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: Text(
          "SKILLPRO",
          style: GoogleFonts.baloo(
            letterSpacing: 5,
            fontSize: 30,
          ),
        ),
        centerTitle: true,
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SizedBox(
              height: MediaQuery.of(context).size.height,
              child: Stack(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(0, 5, 10, 0),
                                child: CircleAvatar(
                                  backgroundImage: Image.network(
                                          'https://flyinryanhawks.org/wp-content/uploads/2016/08/profile-placeholder.png')
                                      .image,
                                  radius: 35,
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    'Name : ${obj.profileData.first.name}',
                                    style: poppins,
                                  ),
                                  Text(
                                    'Email: ${obj.profileData.first.email}',
                                    textAlign: TextAlign.justify,
                                    style: GoogleFonts.poppins(),
                                  ),
                                  Text(
                                    'Role : ${obj.profileData.first.role}',
                                    style: poppins,
                                  ),
                                ],
                              ),
                              const Spacer(),
                              PopupMenuButton<String>(
                                icon: const Icon(
                                  Icons.menu,
                                  size: 30,
                                ),
                                padding: const EdgeInsets.all(0),
                                onSelected: (String result) async {
                                  if (result == "faculty") {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) =>
                                            const ManageFaculty(),
                                      ),
                                    );
                                  } else if (result == "speciality") {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) =>
                                            const ManageSpeciality(),
                                      ),
                                    );
                                  } else if (result == "logout") {
                                    bool k = await _onLogoutPressed();
                                    if (k) {
                                      bool k = await obj.removeLoginStatus();
                                      if (k) {
                                        Navigator.of(context)
                                            .pushNamedAndRemoveUntil(
                                          '/home',
                                          (Route<dynamic> route) => false,
                                        );
                                      }
                                    }
                                  }
                                },
                                itemBuilder: (BuildContext context) =>
                                    <PopupMenuEntry<String>>[
                                  PopupMenuItem<String>(
                                    padding: const EdgeInsets.all(0),
                                    enabled: true,
                                    value: 'student',
                                    child: Center(
                                      child: PopupMenuButton<String>(
                                        child: const Text("Manage Students"),
                                        onCanceled: () {
                                          if (Navigator.canPop(context)) {
                                            Navigator.pop(context);
                                          }
                                        },
                                        onSelected: (result) {
                                          if (result == "add") {
                                            Navigator.of(context).pop();
                                            addBatch(context: context);
                                          } else {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    ManageStudent(
                                                  batches: obj.allBatches
                                                      .where((e) =>
                                                          e.batchName == result)
                                                      .toList()
                                                      .first,
                                                ),
                                              ),
                                            );
                                          }
                                        },
                                        // how much the submenu should offset from parent. This seems to have an upper limit.
                                        offset: const Offset(300, 0),
                                        itemBuilder: (BuildContext context) =>
                                            <PopupMenuEntry<String>>[
                                          for (var i = 0;
                                              i < obj.allBatches.length;
                                              i++)
                                            PopupMenuItem<String>(
                                              value:
                                                  obj.allBatches[i].batchName,
                                              child: Text(
                                                obj.allBatches[i].batchName,
                                              ),
                                            ),
                                          PopupMenuItem<String>(
                                            padding: const EdgeInsets.all(0),
                                            enabled: true,
                                            value: 'add',
                                            child: Center(
                                              child: TextButton.icon(
                                                onPressed: null,
                                                icon: Icon(
                                                  Icons.add_circle,
                                                  color: primaryColor,
                                                  size: 20,
                                                ),
                                                label: Text(
                                                  "Add",
                                                  style: TextStyle(
                                                    color: primaryColor,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const PopupMenuItem<String>(
                                    padding: EdgeInsets.all(0),
                                    enabled: true,
                                    value: 'faculty',
                                    child: Center(
                                      child: Text("Manage Faculty    "),
                                    ),
                                  ),
                                  const PopupMenuItem<String>(
                                    padding: EdgeInsets.all(0),
                                    enabled: true,
                                    value: 'speciality',
                                    child: Center(
                                      child: Text("Manage Speciality"),
                                    ),
                                  ),
                                  PopupMenuItem<String>(
                                    padding: const EdgeInsets.all(0),
                                    enabled: true,
                                    value: 'logout',
                                    child: Center(
                                      child: TextButton.icon(
                                        onPressed: null,
                                        icon: const Icon(
                                          Icons.logout,
                                          color: Colors.black,
                                          size: 20,
                                        ),
                                        label: const Text(
                                          "Logout",
                                          style: TextStyle(
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        SizedBox(
                          child: SfDataGrid(
                            defaultColumnWidth:
                                MediaQuery.of(context).size.width / 3,
                            columnWidthMode: ColumnWidthMode.none,
                            columnWidthCalculationRange:
                                ColumnWidthCalculationRange.allRows,
                            gridLinesVisibility: GridLinesVisibility.vertical,
                            shrinkWrapColumns: true,
                            shrinkWrapRows: true,
                            verticalScrollPhysics:
                                const BouncingScrollPhysics(),
                            allowSorting: true,
                            source:
                                AdminsDataGridSource(context, obj.allAdmins),
                            columns: getColumn(),
                          ),
                        ),
                        const Divider(
                          height: 10.00,
                          thickness: 1.00,
                          color: Colors.black26,
                        ),
                        Container(
                          height: 100,
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: Column(
                        children: [
                          const Divider(
                            height: 10.00,
                            thickness: 1.00,
                            color: Colors.black26,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                InkWell(
                                  onTap: () {
                                    add(context: context);
                                  },
                                  child: Container(
                                    height: 40,
                                    width:
                                        MediaQuery.of(context).size.width / 3,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade300,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        width: 1,
                                        color: Colors.black,
                                      ),
                                    ),
                                    child: const Center(
                                      child: Text(
                                        "Add Admin",
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () async {
                                    _pickFiles();
                                  },
                                  child: Container(
                                    height: 40,
                                    width:
                                        MediaQuery.of(context).size.width / 3,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade300,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        width: 1,
                                        color: Colors.black,
                                      ),
                                    ),
                                    child: Center(
                                      child: loadingBulk
                                          ? const CircularProgressIndicator()
                                          : const Text(
                                              "Add Bulk",
                                            ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

//GridView to display the data as table
List<GridColumn> getColumn() {
  return <GridColumn>[
    GridColumn(
      columnName: 'Name',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('Name', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Email',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('Email', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Password',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child:
            Text('Password', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
  ];
}

class AdminsDataGridSource extends DataGridSource {
  AdminsDataGridSource(this.context, this.allAdmins) {
    buildDataGridRow();
  }
  late AllAdmins? allAdmins;
  late List<DataGridRow> dataGridRows;
  late BuildContext context;
  @override
  DataGridRowAdapter? buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      color: Colors.white,
      cells: [
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: TextButton(
            onPressed: () {
              Adminsdetail adminsdetail = allAdmins!.adminsdetails
                  .where((e) => e.email == row.getCells()[1].value)
                  .toList()
                  .first;
              show(
                context: context,
                firstName: adminsdetail.firstName,
                lastName: adminsdetail.lastName,
                email: adminsdetail.email,
                password: adminsdetail.password,
                phone: adminsdetail.phone,
                personid: adminsdetail.personId,
              );
            },
            child: Text(
              row.getCells()[0].value,
              style: poppins,
              textAlign: TextAlign.center,
              overflow: TextOverflow.visible,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[1].value,
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[2].value,
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
      ],
    );
  }

  @override
  List<DataGridRow> get rows => dataGridRows;
  void buildDataGridRow() {
    dataGridRows = allAdmins!.adminsdetails.map<DataGridRow>((dataGridRow) {
      return DataGridRow(
        cells: [
          DataGridCell<String>(
              columnName: 'Name',
              value: (dataGridRow.firstName + dataGridRow.lastName)),
          DataGridCell<String>(columnName: 'Email', value: dataGridRow.email),
          DataGridCell<String>(
              columnName: 'Password', value: dataGridRow.password),
        ],
      );
    }).toList(growable: true);
  }
}
