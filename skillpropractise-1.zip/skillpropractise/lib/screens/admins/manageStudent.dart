import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firstskillpro/Models/adminModels/allStudent.dart';
import 'package:firstskillpro/Models/adminModels/batches.dart';
import 'package:firstskillpro/Services/api.dart';
import 'package:firstskillpro/utils/adminInfo.dart';
import 'package:firstskillpro/utils/dialogues.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firstskillpro/utils/styling.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:http_parser/http_parser.dart';

class ManageStudent extends StatefulWidget {
  final Batches batches;
  const ManageStudent({Key? key, required this.batches}) : super(key: key);

  @override
  State<ManageStudent> createState() => _ManageStudentState();
}

class _ManageStudentState extends State<ManageStudent> {
  bool first = true;
  bool loading = true;
  late Api obj;

  void getData() async {
    bool k = await obj.getAllStudents(batchName: widget.batches.batchName);
    if (k) {
      if (!mounted) return;
      setState(() {
        loading = false;
      });
    }
  }

  PlatformFile? file;
  bool loadingBulk = false;

  void _pickFiles() async {
    try {
      file = (await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv'],
        allowMultiple: false,
        onFileLoading: (FilePickerStatus status) => print(status),
      ))!
          .files
          .first;
      var formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file!.path!,
            filename: file!.path!.split('/').last,
            contentType: MediaType('multipart/form-data', 'csv')),
      });
      setState(() {
        loadingBulk = true;
      });
      bool k = await obj.addStudentBulk(
        formData,
        batchName: widget.batches.batchName,
      );
      if (k) {
        setState(() {
          loadingBulk = false;
        });

        CustomSnackBar(
          context,
          const Text("Upload Success !!"),
        );
      } else {
        setState(() {
          loadingBulk = false;
        });
        CustomSnackBar(
          context,
          const Text("Error Occurred... "),
        );
      }
    } on PlatformException catch (e) {
      print('Unsupported operation' + e.toString());
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    obj = Provider.of<Api>(context);
    if (first) {
      first = false;
      getData();
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: Text(
          "SKILLPRO",
          style: GoogleFonts.baloo(
            letterSpacing: 5,
            fontSize: 30,
          ),
        ),
        centerTitle: true,
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SizedBox(
              height: MediaQuery.of(context).size.height,
              child: Stack(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Batch : ${widget.batches.batchName}',
                                style: poppins,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          child: SfDataGrid(
                            defaultColumnWidth:
                                MediaQuery.of(context).size.width / 4,
                            columnWidthMode: ColumnWidthMode.none,
                            columnWidthCalculationRange:
                                ColumnWidthCalculationRange.allRows,
                            gridLinesVisibility: GridLinesVisibility.vertical,
                            shrinkWrapColumns: true,
                            shrinkWrapRows: true,
                            verticalScrollPhysics:
                                const BouncingScrollPhysics(),
                            allowSorting: true,
                            source: AdminsDataGridSource(
                              context,
                              obj.allstudent,
                              widget.batches.batchName,
                            ),
                            columns: getColumn(),
                          ),
                        ),
                        const Divider(
                          height: 10.00,
                          thickness: 1.00,
                          color: Colors.black26,
                        ),
                        Container(
                          height: 100,
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: Column(
                        children: [
                          const Divider(
                            height: 10.00,
                            thickness: 1.00,
                            color: Colors.black26,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                InkWell(
                                  onTap: () {
                                    addStudent(
                                      context: context,
                                      batchName: widget.batches.batchName,
                                    );
                                  },
                                  child: Container(
                                    height: 40,
                                    width:
                                        MediaQuery.of(context).size.width / 3,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade300,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        width: 1,
                                        color: Colors.black,
                                      ),
                                    ),
                                    child: const Center(
                                      child: Text(
                                        "Add Student",
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () async {
                                    _pickFiles();
                                  },
                                  child: Container(
                                    height: 40,
                                    width:
                                        MediaQuery.of(context).size.width / 3,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade300,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        width: 1,
                                        color: Colors.black,
                                      ),
                                    ),
                                    child: Center(
                                      child: loadingBulk
                                          ? const CircularProgressIndicator()
                                          : const Text(
                                              "Add Bulk",
                                            ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

//GridView to display the data as table
List<GridColumn> getColumn() {
  return <GridColumn>[
    GridColumn(
      columnName: 'RegNo.',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('RegNo.', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Name',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('Name', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Email',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('Email', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Password',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child:
            Text('Password', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
  ];
}

class AdminsDataGridSource extends DataGridSource {
  AdminsDataGridSource(this.context, this.allStudent, this.batchName) {
    buildDataGridRow();
  }
  late List<AllStudent> allStudent;
  late List<DataGridRow> dataGridRows;
  late BuildContext context;
  late String batchName;
  @override
  DataGridRowAdapter? buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      color: Colors.white,
      cells: [
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: TextButton(
            onPressed: () {
              AllStudent student = allStudent
                  .where((e) => e.email == row.getCells()[2].value)
                  .toList()
                  .first;
              showStudent(
                context: context,
                personid: student.personid,
                batchName: batchName,
                studentId: student.studentId,
                firstName: student.firstName,
                lastName: student.lastName,
                email: student.email,
                password: student.password,
                phone: student.phone,
              );
            },
            child: Text(
              row.getCells()[0].value,
              style: poppins,
              textAlign: TextAlign.center,
              overflow: TextOverflow.visible,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[1].value,
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[2].value,
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[3].value,
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
      ],
    );
  }

  @override
  List<DataGridRow> get rows => dataGridRows;
  void buildDataGridRow() {
    dataGridRows = allStudent.map<DataGridRow>((dataGridRow) {
      return DataGridRow(
        cells: [
          DataGridCell<String>(
              columnName: 'RegNo.', value: dataGridRow.studentId),
          DataGridCell<String>(
              columnName: 'Name',
              value: (dataGridRow.firstName + dataGridRow.lastName)),
          DataGridCell<String>(columnName: 'Email', value: dataGridRow.email),
          DataGridCell<String>(
              columnName: 'Password', value: dataGridRow.password),
        ],
      );
    }).toList(growable: true);
  }
}
