import 'package:firstskillpro/Services/api.dart';
import 'package:firstskillpro/screens/admins/homePage.dart';
import 'package:firstskillpro/screens/login/build_login.dart';
import 'package:firstskillpro/screens/faculty/logged_in.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LoginWidget extends StatefulWidget {
  const LoginWidget({Key? key}) : super(key: key);

  @override
  _LoginWidgetState createState() => _LoginWidgetState();
}

class _LoginWidgetState extends State<LoginWidget> {
  bool first = true;
  bool isLoggedIn = false;
  bool loading = true;
  late Api obj;

  void getData() async {
    bool k = await obj.getLoginStatus();
    if (k) {
      print("User already logged In");
      print(obj.globalEmail);
      print(obj.globalPassword);
      bool k = await obj.loginStatusCheck(
          mail: obj.globalEmail, password: obj.globalPassword);
      if (k) {
        if (!mounted) return;
        setState(() {
          loading = false;
          isLoggedIn = true;
        });
      }
    } else {
      if (!mounted) return;
      setState(() {
        loading = false;
        isLoggedIn = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    obj = Provider.of<Api>(context);
    if (first) {
      first = false;
      getData();
    }

    return Scaffold(
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : isLoggedIn
              ? (obj.loginCheck!.role.toUpperCase() == 'ADMIN' &&
                      obj.loginCheck!.status.toUpperCase() == 'TRUE')
                  ? const AdminHomePage()
                  : ((obj.loginCheck!.role.toUpperCase() == 'STUDENT' ||
                              obj.loginCheck!.role.toUpperCase() ==
                                  'FACULTY') &&
                          obj.loginCheck!.status.toUpperCase() == 'TRUE')
                      ? const FacultyLoggedIn()
                      : const BuildLogin()
              : const BuildLogin(),
    );
  }
}
