import 'package:firstskillpro/Services/api.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firstskillpro/utils/styling.dart';
import 'package:provider/provider.dart';

class FacultyReferences extends StatefulWidget {
  const FacultyReferences({
    Key? key,
  }) : super(key: key);

  @override
  State<FacultyReferences> createState() => _FacultyReferencesState();
}

class _FacultyReferencesState extends State<FacultyReferences> {
  List<bool> referencePicked = [];
  Map<int, String> matter = {};
  bool first = true;
  bool loading = true;
  late Api obj;

  void getFacultyData() async {
    bool k = await obj.getReferenceList(mail: obj.profileData.first.email);
    if (k) {
      if (!mounted) return;
      setState(() {
        for (var i = 0; i < obj.referenceList.length; i++) {
          referencePicked.add(false);
          matter[obj.referenceList[i].competencyevaluationId] = "";
          if (!allStudents.contains(obj.referenceList[i].studentid)) {
            allStudents.add(obj.referenceList[i].studentid);
          }
        }
        loading = false;
      });
    }
  }

  void getStudentData() async {
    bool k =
        await obj.getReferenceStudentList(mail: obj.profileData.first.email);
    if (k) {
      if (!mounted) return;
      setState(() {
        loading = false;
      });
    }
  }

  String? selectedStudent;
  List<String> allStudents = [];
  @override
  Widget build(BuildContext context) {
    obj = Provider.of<Api>(context);
    if (first) {
      first = false;
      loading = true;
      obj.loginCheck!.role == 'student' ? getStudentData() : getFacultyData();
    }
    return loading
        ? const Center(
            child: CircularProgressIndicator(),
          )
        : SingleChildScrollView(
            child: Column(
              children: <Widget>[
                const SizedBox(
                  height: 25,
                  child: Divider(
                    height: 5,
                    thickness: 2,
                  ),
                ),
                obj.loginCheck!.role != 'faculty'
                    ? Container()
                    : Card(
                        elevation: 0,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Colors.blue.shade400,
                          ),
                          padding: const EdgeInsets.all(0),
                          height: 40,
                          width: MediaQuery.of(context).size.width,
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton(
                              underline: DropdownButtonHideUnderline(
                                child: Container(),
                              ),
                              iconEnabledColor: Colors.white,
                              iconSize: selectedStudent == null ? 24 : 0,
                              items: allStudents.map((type) {
                                return DropdownMenuItem(
                                  child: Text(
                                    type,
                                    style: const TextStyle(fontSize: 16),
                                  ),
                                  value: type,
                                );
                              }).toList(),
                              hint: const Padding(
                                padding: EdgeInsets.all(10),
                                child: Text(
                                  "Choose Student",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              value: selectedStudent,
                              onChanged: (String? newValue) {
                                setState(() {
                                  selectedStudent = newValue;
                                });
                              },
                            ),
                          ),
                        ),
                      ),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: (obj.loginCheck!.role == 'faculty')
                      ? obj.referenceList
                          .where((e) => e.studentid == selectedStudent)
                          .toList()
                          .length
                      : obj.referenceStudentList.length,
                  itemBuilder: (context, i) {
                    return Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                                obj.loginCheck!.role == 'student'
                                    ? '${i + 1}. ${obj.referenceStudentList[i].facultyname} - ${obj.referenceStudentList[i].evaluationtype}'
                                    : '${i + 1}. ${obj.referenceList.where((e) => e.studentid == selectedStudent).toList()[i].studentname} - ${obj.referenceList.where((e) => e.studentid == selectedStudent).toList()[i].studentid}',
                                style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.bold)),
                            obj.loginCheck!.role == 'student'
                                ? Container()
                                : Checkbox(
                                    value: false,
                                    onChanged: (bool? m) async {
                                      setState(() {
                                        loading = true;
                                      });
                                      var formData = {
                                        "competencyevaluationid": obj
                                            .referenceList
                                            .where((e) =>
                                                e.studentid == selectedStudent)
                                            .toList()[i]
                                            .competencyevaluationId,
                                        "refermatter": matter[obj.referenceList
                                            .where((e) =>
                                                e.studentid == selectedStudent)
                                            .toList()[i]
                                            .competencyevaluationId],
                                        "criteriaid": obj.referenceList
                                            .where((e) =>
                                                e.studentid == selectedStudent)
                                            .toList()[i]
                                            .criteriaid,
                                      };
                                      bool k = await obj.submitReference(
                                        formData: formData,
                                      );
                                      if (k) {
                                        setState(() {
                                          loading = false;
                                        });
                                      }
                                    }),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 25),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                      obj.loginCheck!.role == 'student'
                                          ? 'Competency: ${obj.referenceStudentList[i].competencyname}'
                                          : 'Competency: ${obj.referenceList.where((e) => e.studentid == selectedStudent).toList()[i].competencyname}',
                                      style: GoogleFonts.poppins()),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                      obj.loginCheck!.role == 'student'
                                          ? 'Criteria qs: ${obj.referenceStudentList[i].criteriaqs}'
                                          : 'Criteria qs: ${obj.referenceList.where((e) => e.studentid == selectedStudent).toList()[i].criteriaqs}',
                                      style: GoogleFonts.poppins()),
                                ],
                              ),
                              obj.loginCheck!.role == 'student'
                                  ? Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.8,
                                          child: Text(
                                            'Reference : ${obj.referenceStudentList[i].reference}',
                                            style: GoogleFonts.poppins(),
                                          ),
                                        ),
                                      ],
                                    )
                                  : Container(),
                              obj.loginCheck!.role == 'student'
                                  ? Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Asked On : ${obj.referenceStudentList[i].datetime.split(" ")[0]}',
                                          style: GoogleFonts.poppins(),
                                        ),
                                      ],
                                    )
                                  : Container(),
                              obj.loginCheck!.role == 'student'
                                  ? Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Speciality : ${obj.referenceStudentList[i].specialityname}',
                                          style: GoogleFonts.poppins(),
                                        ),
                                      ],
                                    )
                                  : Container(),
                              obj.loginCheck!.role == 'student'
                                  ? Container()
                                  : Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        ElevatedButton(
                                          onPressed: () {
                                            setState(() {
                                              referencePicked[i] =
                                                  !referencePicked[i];
                                            });
                                          },
                                          child: Wrap(
                                            crossAxisAlignment:
                                                WrapCrossAlignment.center,
                                            children: [
                                              const Icon(Icons.add),
                                              Text(
                                                'Add Reference',
                                                style: poppins,
                                              )
                                            ],
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            elevation: 20,
                                            shadowColor: Colors.black,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(30.0),
                                            ),
                                            primary: secondaryColor,
                                          ),
                                        ),
                                      ],
                                    ),
                              obj.loginCheck!.role == 'student'
                                  ? Container()
                                  : referencePicked[i]
                                      ? Card(
                                          elevation: 10,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(30.0),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 20, vertical: 15),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: <Widget>[
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: const [
                                                    Text("Recommendations"),
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    Icon(Icons
                                                        .auto_stories_rounded),
                                                  ],
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                Container(
                                                  // height: 50,
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width /
                                                      1.3,
                                                  child: TextFormField(
                                                    initialValue: matter[obj
                                                        .referenceList
                                                        .where((e) =>
                                                            e.studentid ==
                                                            selectedStudent)
                                                        .toList()[i]
                                                        .competencyevaluationId],
                                                    onChanged: (data) {
                                                      matter[obj.referenceList
                                                          .where((e) =>
                                                              e.studentid ==
                                                              selectedStudent)
                                                          .toList()[i]
                                                          .competencyevaluationId] = data;
                                                    },
                                                    maxLines: null,
                                                    keyboardType:
                                                        TextInputType.multiline,
                                                    decoration:
                                                        const InputDecoration(
                                                      border:
                                                          OutlineInputBorder(),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : Container(),
                              const SizedBox(
                                height: 25,
                                child: Divider(
                                  height: 5,
                                  thickness: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          );
  }
}
