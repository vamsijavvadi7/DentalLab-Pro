import 'package:firstskillpro/screens/faculty/dashboard/demo.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import '../../../Models/competencyDetails.dart';
import '../../../Services/api.dart';
import '../../../utils/styling.dart';

class Datasearch extends SearchDelegate<String> {
  final int competencyID;
  Datasearch(this.competencyID);

  Api? obj;

  @override
  List<Widget> buildActions(BuildContext context) {
    // actions for app bar
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = "";
        },
      )
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    // leading icon on the left of the app bar
    return IconButton(
      icon: AnimatedIcon(
        icon: AnimatedIcons.menu_arrow,
        progress: transitionAnimation,
      ),
      onPressed: () {
        close(context, "");
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    //show results based on selection
    final suggestion = query.isEmpty ? "" : query;

    return ListView.builder(
      itemBuilder: (context, index) => ListTile(
        onTap: () {},
        leading: query.isEmpty ? null : const Icon(Icons.search),
        title: RichText(
          text: TextSpan(
            text: suggestion.substring(0, query.length),
            style: const TextStyle(
                color: Colors.black, fontWeight: FontWeight.bold),
            children: [
              TextSpan(
                text: suggestion.substring(query.length),
                style: const TextStyle(
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
      ),
      itemCount: 1,
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    //show when someone searches for something
    final suggestion = query.isEmpty ? "" : query;
    obj = Provider.of<Api>(context);
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: SfDataGrid(
        defaultColumnWidth: MediaQuery.of(context).size.width / 4,
        columnWidthMode: ColumnWidthMode.none,
        columnWidthCalculationRange: ColumnWidthCalculationRange.allRows,
        gridLinesVisibility: GridLinesVisibility.vertical,
        shrinkWrapColumns: true,
        shrinkWrapRows: true,
        verticalScrollPhysics: const BouncingScrollPhysics(),
        allowSorting: true,
        source: CompetenciesDataGridSource(
          obj!.competencyDetailsList
              .where((e) =>
                  e.regno.toLowerCase().contains(suggestion.toLowerCase()) ||
                  e.name.toLowerCase().contains(suggestion.toLowerCase()))
              .toList(),
          context,
          competencyID,
        ),
        columns: getColumn(),
      ),
    );
  }
}

//GridView to display the data as table
List<GridColumn> getColumn() {
  return <GridColumn>[
    GridColumn(
      columnName: 'RegNo',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('RegNo', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Name',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('Name', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Self',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text('Self', style: GoogleFonts.poppins(color: Colors.white)),
      ),
    ),
    GridColumn(
      columnName: 'Faculty',
      label: Container(
        color: primaryColor,
        alignment: Alignment.center,
        child: Text(
          'Faculty',
          style: GoogleFonts.poppins(color: Colors.white),
        ),
      ),
    ),
  ];
}

class CompetenciesDataGridSource extends DataGridSource {
  CompetenciesDataGridSource(
      this.competencyDetails, this.context, this.competencyID) {
    buildDataGridRow();
  }
  late List<CompetencyDetails> competencyDetails;
  late List<DataGridRow> dataGridRows;
  BuildContext context;
  int competencyID;
  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      color: Colors.white,
      cells: [
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute<dynamic>(
                  builder: (BuildContext context) => DemoTable(
                    competencyid: competencyID,
                    studentid: row.getCells()[0].value,
                  ),
                ),
              );
            },
            child: Text(
              row.getCells()[0].value,
              style: poppins,
              textAlign: TextAlign.center,
              overflow: TextOverflow.visible,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[1].value,
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[2].value.toString() == "0"
                ? "NA"
                : row.getCells()[2].value.toString(),
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Text(
            row.getCells()[3].value.toString() == "0"
                ? "NA"
                : row.getCells()[3].value.toString(),
            style: poppins,
            textAlign: TextAlign.center,
            overflow: TextOverflow.visible,
          ),
        ),
      ],
    );
  }

  @override
  List<DataGridRow> get rows => dataGridRows;
  void buildDataGridRow() {
    dataGridRows = competencyDetails.map<DataGridRow>((dataGridRow) {
      return DataGridRow(cells: [
        DataGridCell<String>(columnName: 'RegNo', value: dataGridRow.regno),
        DataGridCell<String>(columnName: 'Name', value: dataGridRow.name),
        DataGridCell<int>(columnName: 'Self', value: dataGridRow.self),
        DataGridCell<int>(columnName: 'Faculty', value: dataGridRow.faculty),
      ]);
    }).toList(growable: true);
  }
}
