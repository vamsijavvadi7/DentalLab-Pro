import 'package:firstskillpro/Services/api.dart';
import 'package:firstskillpro/utils/dialogues.dart';
import 'package:flutter/material.dart';
import 'package:firstskillpro/utils/styling.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Edit extends StatefulWidget {
  const Edit({Key? key}) : super(key: key);
  @override
  _EditState createState() => _EditState();
}

class _EditState extends State<Edit> {
  bool loading = false;
  bool first = true;
  late Api obj;
  late String name;
  late String phoneNumber;
  late String regNo;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    obj = Provider.of<Api>(context);
    if (first) {
      first = false;
      name = obj.profileData.first.name;
      phoneNumber = obj.profileData.first.phone;
      regNo = obj.profileData.first.regno;
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "EDIT DETAILS",
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: primaryColor,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 5, 15, 5),
              child: TextFormField(
                style: GoogleFonts.poppins(color: Colors.black),
                cursorColor: Colors.black,
                keyboardType: TextInputType.name,
                textAlign: TextAlign.left,
                initialValue: name,
                onChanged: (text) {
                  setState(() {
                    name = text;
                  });
                },
                decoration: InputDecoration(
                  hintText: "Name",
                  hintStyle: GoogleFonts.poppins(color: Colors.black),
                  prefixIcon: const Icon(
                    Icons.person_rounded,
                    color: Colors.black,
                  ),
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(30.0)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 5, 15, 5),
              child: TextFormField(
                style: GoogleFonts.poppins(color: Colors.black),
                cursorColor: Colors.black,
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly
                ],
                textAlign: TextAlign.left,
                initialValue: phoneNumber,
                onChanged: (text) {
                  setState(() {
                    phoneNumber = text;
                  });
                },
                decoration: InputDecoration(
                  hintText: "Phone Number",
                  hintStyle: GoogleFonts.poppins(color: Colors.black),
                  prefixIcon: const Icon(
                    Icons.dialpad_rounded,
                    color: Colors.black,
                  ),
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(30.0)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 5, 15, 5),
              child: TextFormField(
                style: GoogleFonts.poppins(color: Colors.black),
                cursorColor: Colors.black,
                keyboardType: TextInputType.text,
                textAlign: TextAlign.left,
                initialValue: regNo,
                onChanged: (text) {
                  setState(() {
                    regNo = text;
                  });
                },
                decoration: InputDecoration(
                  hintText: "Reg no.",
                  hintStyle: GoogleFonts.poppins(color: Colors.black),
                  prefixIcon: const Icon(
                    Icons.app_registration,
                    color: Colors.black,
                  ),
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(30.0)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: width - (width * 0.10),
              child: ElevatedButton(
                onPressed: loading
                    ? () {}
                    : () async {
                        setState(() {
                          loading = true;
                        });
                        bool k = await obj.editProfile(
                          regno: regNo,
                          firstname: name.split(" ")[0],
                          lastname: name.split(" ")[1],
                          phonenum: phoneNumber,
                          role: obj.profileData.first.role,
                        );
                        if (k) {
                          CustomSnackBar(
                            context,
                            const Text(
                              "Profile Edit Success",
                            ),
                          );
                          setState(() {
                            loading = false;
                          });
                        } else {
                          CustomSnackBar(
                            context,
                            const Text(
                              "Error Occured..",
                            ),
                          );
                          setState(() {
                            loading = false;
                          });
                        }
                      },
                child: loading
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : Text(
                        "Submit",
                        style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
                      ),
                style: ElevatedButton.styleFrom(
                  elevation: 20,
                  shadowColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                  primary: secondaryColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
