package com.example.firstskillpro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
